import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AccountComponent } from './components/account/account.component';
import { ProfileComponent } from './components/account/profile/profile.component';
import { OrdersComponent } from './components/account/orders/orders.component';
import { AddressComponent } from './components/account/address/address.component';
import { PasswordComponent } from './components/account/password/password.component';

import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AdminhomeComponent } from './components/adminhome/adminhome.component';
import { ProductsComponent } from './components/products/products.component';
import { CategoriesComponent } from './components/categories/categories.component';
import { WelcomecarouselComponent } from './components/welcomecarousel/welcomecarousel.component';
import { CustomerProductsComponent } from './components/customer-products/customer-products.component';
import { CartComponent } from './components/cart/cart.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { FeedbackComponent } from './components/feedback/feedback.component';
import { WelcomepgComponent } from './components/welcomepg/welcomepg.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { CustomerdetComponent } from './components/customerdet/customerdet.component';
import { LogoutComponent } from './components/account/logout/logout.component';

const routes: Routes = [

  

  { path: "", component: WelcomepgComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent},
  { path: 'about-us', component: AboutUsComponent },
  { path: 'feedback', component: FeedbackComponent },

  { path: 'adminhome', component: AdminhomeComponent },
  { path: 'products', component: ProductsComponent },

  // Customer product view
  { path: 'products/:category', component: CustomerProductsComponent },

  { path: 'cart', component: CartComponent },
  { path: 'categories', component: CategoriesComponent },
  { path: 'carouselhome', component: WelcomecarouselComponent },
  { path: 'checkout', component: CheckoutComponent},
  {path:'customerdet',component:CustomerdetComponent},

  {
    path: 'account',
    component: AccountComponent,
    children: [
      { path: 'profile', component: ProfileComponent },
      { path: 'orders', component: OrdersComponent },
      { path: 'address', component: AddressComponent },
      { path: 'password', component: PasswordComponent },
      {path : 'logout' ,component:LogoutComponent},
      { path: '', redirectTo: 'profile', pathMatch: 'full' }
    ]
  },

  // Fallback (optional)
  { path: '**', redirectTo: 'carouselhome' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
