import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: false,
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']   // ✅ MUST be styleUrls
})
export class AppComponent {
  title = 'EcommerceWebsite';
  showNavbar = true;

  constructor(private router: Router) {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        // hide navbar ONLY on home page
        this.showNavbar = event.urlAfterRedirects !== '/';
      }
    });
  }
}
