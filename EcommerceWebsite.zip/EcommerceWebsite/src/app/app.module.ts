import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

/* ---- non-standalone components (declare these) ---- */
import { AccountComponent } from './components/account/account.component';
import { ProfileComponent } from './components/account/profile/profile.component';
import { OrdersComponent } from './components/account/orders/orders.component';
import { AddressComponent } from './components/account/address/address.component';
import { PasswordComponent } from './components/account/password/password.component';

import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { AdminhomeComponent } from './components/adminhome/adminhome.component';
import { ProductsComponent } from './components/products/products.component';
import { CategoriesComponent } from './components/categories/categories.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { WelcomecarouselComponent } from './components/welcomecarousel/welcomecarousel.component';
import { FeedbackComponent } from './components/feedback/feedback.component';
import { CustomerdetComponent } from './components/customerdet/customerdet.component';
import { CartComponent } from './components/cart/cart.component';
import { WelcomepgComponent } from './components/welcomepg/welcomepg.component';

/* If ForgotPasswordComponent is NOT standalone, keep it declared; 
   if it's standalone, move it to the "imports" array below instead. */
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';

/* ---- standalone components (import these) ----
   Make sure these files have `standalone: true` in their @Component decorator.
   If any of these are NOT standalone, move them to declarations above.
*/
import { CustomerProductsComponent } from './components/customer-products/customer-products.component';
import { CustomerProductGridComponent } from './components/customer-product-grid/customer-product-grid.component';
import { CheckoutComponent } from './components/checkout/checkout.component';
import { LogoutComponent } from './components/account/logout/logout.component';
import { NavbarComponent } from './components/navbar/navbar.component';

@NgModule({
  declarations: [
    /* core app + non-standalone components */
    AppComponent,

    AccountComponent,
    ProfileComponent,
    OrdersComponent,
    AddressComponent,
    PasswordComponent,
    LoginComponent,
    RegisterComponent,
    AdminhomeComponent,
    ProductsComponent,
    CategoriesComponent,
    AboutUsComponent,
    WelcomecarouselComponent,
    FeedbackComponent,
    CustomerdetComponent,
    WelcomepgComponent,
    ForgotPasswordComponent,
    CartComponent,
    CheckoutComponent,
    NavbarComponent ,
    LogoutComponent // <-- assume NOT standalone; if it *is*, remove from here and add to imports
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    NgxPaginationModule,

    /* standalone components — import them (they must have standalone: true) */
    CustomerProductsComponent,
    CustomerProductGridComponent
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
