import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../../models/Customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService { 

  private apiUrl = 'http://localhost:8084/api/user/details'; 
  baseUrl = 'http://localhost:8084/customer/api';

  constructor(private http: HttpClient) { }

  getAuthenticatedCustomerDetails(): Observable<Customer> {
    const token = localStorage.getItem('jwt_token'); 
    let headers = new HttpHeaders();

    if (token) {
      headers = headers.set('Authorization', 'Bearer ' + token);
    }

    return this.http.get<Customer>(this.apiUrl, { headers });
  }

  getAllCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(this.baseUrl);
  }

  getCustomerById(id: number): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseUrl}/${id}`);
  }

  saveCustomer(customer: Customer): Observable<Customer> {
    return this.http.post<Customer>(this.baseUrl, customer);
  }

  updateCustomerByCustId(id: number, data: any): Observable<Customer> {
    return this.http.put<Customer>(`${this.baseUrl}/${id}`, data);
  }

  deleteCustById(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}
