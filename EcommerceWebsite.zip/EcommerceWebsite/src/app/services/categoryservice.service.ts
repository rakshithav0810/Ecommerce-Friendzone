import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ProductCategory } from '../../models/product-category';

@Injectable({
  providedIn: 'root'
})
export class CategoryserviceService {
   baseUrl = "http://localhost:8084/productCategory/api";

  constructor(private http: HttpClient) { }

  /**
   * Existing method: Fetches all product categories.
   */
  getAllCategories(): Observable<ProductCategory[]> {
    return this.http.get<ProductCategory[]>(this.baseUrl);
  }
  
  /**
   * NEW METHOD: Fetches a single category by its ID.
   * Assumes backend endpoint for retrieving a single category is: GET /productCategory/api/{id}
   */
  getCategoryById(id: number): Observable<ProductCategory> {
    return this.http.get<ProductCategory>(`${this.baseUrl}/${id}`);
  }

  /**
   * Existing method: Saves a new category.
   */
  saveCategory(data: any) {
    return this.http.post(`${this.baseUrl}`, data);
  }

  /**
   * Existing method: Updates an existing category by ID.
   */
  updateCategoryByCategoryId(id: number, data: any) {
    return this.http.put(`${this.baseUrl}/${id}`, data);
  }

  /**
   * Existing method: Deletes a category by ID.
   */
  deleteCategoryByCategoryId(id: number) {
    return this.http.delete(`${this.baseUrl}/${id}`);
  }
}