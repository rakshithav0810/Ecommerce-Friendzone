import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Customer {
  cid: number;
  firstName: string;
  lastName: string;
  email: string;
  userName: string;
  password?: string;
  role: string;
  mobileNo: string;
  address: string;
}

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:8084/customer/api';

  private loggedInUser!: Customer | null;

  constructor(private http: HttpClient) {}

  // ---------------- LOGIN ----------------
  loginUser(customer: any): Observable<Customer> {
    return this.http.post<Customer>(`${this.baseUrl}/login`, customer);
  }

  // ---------------- REGISTER ----------------
  registerUser(customer: any): Observable<Customer> {
    return this.http.post<Customer>(`${this.baseUrl}/register`, customer);
  }

  // ---------------- STORE USER ----------------
  saveUser(customer: Customer) {
    this.loggedInUser = customer;
    localStorage.setItem('customer', JSON.stringify(customer));
  }

  // ---------------- GET LOGGED USER ----------------
  getLoggedInUser(): Customer | null {
    if (this.loggedInUser) return this.loggedInUser;

    const saved = localStorage.getItem('customer');
    if (saved) {
      this.loggedInUser = JSON.parse(saved);
      return this.loggedInUser;
    }
    return null;
  }

  // ---------------- GET PROFILE ----------------
  getProfile(): Observable<Customer> {
    const user = this.getLoggedInUser();
    return this.http.get<Customer>(`${this.baseUrl}/profile/${user?.cid}`);
  }

  // ---------------- UPDATE CUSTOMER ----------------
  updateCustomer(data: Customer): Observable<Customer> {
    return this.http.put<Customer>(`${this.baseUrl}/${data.cid}`, data);
  }

  // ---------------- UPDATE PASSWORD ----------------
  updatePassword(newPassword: string): Observable<Customer> {
    const user = this.getLoggedInUser();
    if (!user) throw new Error("Not logged in");

    const updatedUser: Customer = { ...user, password: newPassword };

    return this.updateCustomer(updatedUser);
  }

  // ---------------- GET ADDRESS ----------------
  getAddress(): string {
    const user = this.getLoggedInUser();
    return user?.address ?? "No address found";
  }
  getCustomerByEmail(email: string): Observable<Customer> {
    return this.http.get<Customer>(`${this.baseUrl}/by-email?email=${email}`);
  }
  getOrders(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:8084/order/api');
  }
  updatePasswordByEmail(email: string, newPassword: string) {
    return this.http.put(`${this.baseUrl}/update-password?email=${email}`, { newPassword });
  }
  getOrdersByCustomer(customerId: number): Observable<any[]> {
    return this.http.get<any[]>(
      `http://localhost:8084/order/api/customer/${customerId}`
    );
  }
  // ---------------- LOGOUT ----------------
logout() {
  this.loggedInUser = null;
  localStorage.removeItem('customer');
}

  
  
  
  
  
}
