import { Component, OnInit } from '@angular/core';
import { CartService } from '../../services/cart.service';
import { UserService } from '../../services/user.service';
import { Router, NavigationEnd } from '@angular/router'; // 🔴 ADD
import { filter } from 'rxjs/operators';                 // 🔴 ADD

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartItems: any[] = [];
  totalAmount = 0;

  constructor(
    private cartService: CartService,
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {

    this.loadCart();

    // 🔴 Reload cart on every navigation to /cart
    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => {
        this.loadCart();
      });
  }

  // 🔴 NEW METHOD (logic moved here)
  loadCart() {
    const user = this.userService.getLoggedInUser();

    if (!user) {
      this.router.navigate(['/login']);
      return;
    }

    this.cartService.getCartItems(user.cid).subscribe({
      next: data => {
        this.cartItems = data;
        this.calculateTotal();
      },
      error: err => console.error(err)
    });
  }

  calculateTotal() {
    this.totalAmount = this.cartItems.reduce(
      (sum, item) => sum + item.product.unitPrice * item.quantity,
      0
    );
  }

  proceedToCheckout() {
    this.router.navigate(['/checkout']);
  }
}
