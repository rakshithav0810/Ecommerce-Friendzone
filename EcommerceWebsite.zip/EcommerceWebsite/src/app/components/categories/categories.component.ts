import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ProductCategory } from '../../../models/product-category';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CategoryserviceService } from '../../services/categoryservice.service';

@Component({
  selector: 'app-categories',
  standalone: false,
  templateUrl: './categories.component.html',
  styleUrl: './categories.component.css'
})
export class CategoriesComponent implements OnInit {

  categories: ProductCategory[] = [];
  categoryForm!: FormGroup;

  editMode = false;
  editId: number | null = null;

  constructor(private fb: FormBuilder, private service: CategoryserviceService,private cd:ChangeDetectorRef) {}

  ngOnInit(): void {
    this.categoryForm = this.fb.group({
      categoryName: ['']
    });

    this.loadCategories();
  }

  loadCategories() {
    this.service.getAllCategories().subscribe(res => this.categories = res);
  }

  onSubmit() {
    const data = this.categoryForm.value;

    if (!this.editMode) {
      this.service.saveCategory(data).subscribe(() => {
        this.loadCategories();
        this.categoryForm.reset();
      });
    } else {
      this.service.updateCategoryByCategoryId(this.editId!, data).subscribe(() => {
        this.loadCategories();
        this.resetForm();
      });
    }
  }

  editCategory(c: ProductCategory) {
    this.editMode = true;
    this.editId = c.id;

    this.categoryForm.setValue({
      categoryName: c.categoryName
    });
  }

  resetForm() {
    this.editMode = false;
    this.editId = null;
    this.categoryForm.reset();
  }

  deleteCategoryByCategoryId(id: number) {
    if (!confirm("Delete this category?")) return;
  
    this.categories = this.categories.filter(c => c.id !== id);
  
    this.service.deleteCategoryByCategoryId(id).subscribe({
      next: () => {
        this.loadCategories();
  
        setTimeout(() => {
          this.cd.detectChanges();
        }, 0);
      },
      error: err => {
        console.error(err);
        this.loadCategories();
      }
    });
  }
}