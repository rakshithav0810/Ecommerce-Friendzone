import { Component } from '@angular/core';
import { Customer } from '../../../models/Customer';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  customer = new Customer();

  constructor(
    private userService: UserService,
    private router: Router
  ) {}

  loginUser() {
    this.userService.loginUser(this.customer).subscribe(
      (loginResponse: any) => {

        if (!loginResponse) {
          alert("Login failed!");
          return;
        }

        const email = this.customer.email;

        this.userService.getCustomerByEmail(email).subscribe(
          (customerDetails: any) => {
            // Save the logged-in user
            this.userService.saveUser(customerDetails);

            if (loginResponse.role === "Customer") {
              alert("Customer Logged in successfully!");
              this.router.navigate(['/carouselhome']);   // ✅ CUSTOMER HOME PAGE
            } 
            else if (loginResponse.role === "Admin") {
              alert("Admin Logged in successfully!");
              this.router.navigate(['/adminhome']);       // ✅ FIXED PATH
            }
          }
        );
      },
      (err) => {
        alert("Incorrect email or password");
      }
    );
  }
}
