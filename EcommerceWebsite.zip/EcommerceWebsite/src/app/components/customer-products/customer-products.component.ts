import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductserviceService } from '../../services/productservice.service';
import { CartService } from '../../services/cart.service';
import { UserService } from '../../services/user.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-customer-products',
  standalone: true,
  templateUrl: './customer-products.component.html',
  styleUrls: ['./customer-products.component.css'],
  imports: [CommonModule]
})
export class CustomerProductsComponent implements OnInit {

  

  allProducts: any[] = [];
  filteredProducts: any[] = [];
  category: string = "";

  constructor(
    private route: ActivatedRoute,
    private productService: ProductserviceService,
    private cartService: CartService,
    private userService: UserService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.category = params['category'];
      this.loadProducts();
    });
  }

  loadProducts() {
    this.productService.getAllProducts().subscribe(products => {
      this.allProducts = products;

      this.filteredProducts = this.allProducts.filter(p =>
        p.category?.categoryName?.toLowerCase() === this.category.toLowerCase()
      );
    });
  }

  // ✅ ADD TO CART
  addToCart(productId: number) {
    const user = this.userService.getLoggedInUser();

    if (!user) {
      alert('Please login first');
      this.router.navigate(['/login']);
      return;
    }

    this.cartService.addToCart(user.cid, productId).subscribe({
      next: () => alert('Added to cart!'),
      error: err => console.error(err)
    });
  }

  buyNow(productId: number) {
    const user = this.userService.getLoggedInUser();
  
    if (!user) {
      alert('Please login first');
      this.router.navigate(['/login']);
      return;
    }
  
    
    
        // ✅ Navigate ONLY after backend confirms save
        this.router.navigate(['/cart']);
     
  }
  
}
