import { Component, OnInit } from '@angular/core';
import { PaymentService } from '../../services/payment.service';
import { CartService } from '../../services/cart.service';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

declare var Razorpay: any;

@Component({
  selector: 'app-checkout',
  standalone: false,
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  cartItems: any[] = [];
  totalAmount = 0;
  user: any;

  constructor(
    private paymentService: PaymentService,
    private cartService: CartService,
    private userService: UserService,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.user = this.userService.getLoggedInUser();

    if (!this.user) {
      alert('Please login first');
      this.router.navigate(['/login']);
      return;
    }

    this.cartService.getCartItems(this.user.cid).subscribe(items => {
      this.cartItems = items;
      this.calculateTotal();
    });
  }

  calculateTotal() {
    this.totalAmount = this.cartItems.reduce(
      (sum, item) => sum + item.product.unitPrice * item.quantity,
      0
    );
  }

  payNow() {
    this.paymentService.createOrder(this.totalAmount).subscribe(order => {

      const options = {
        key: 'rzp_test_Rr6AZ5xurYtSR2',
        amount: order.amount,
        currency: order.currency,
        name: 'Ecommerce Website',
        description: 'Order Payment',
        order_id: order.id,

        handler: (response: any) => {
          // ✅ unchanged
          this.afterPaymentSuccess(response);
        },

        prefill: {
          name: this.user.firstName,
          email: this.user.email,
          contact: this.user.mobileNo
        },

        theme: {
          color: '#3399cc'
        }
      };

      const rzp = new Razorpay(options);
      rzp.open();
    });
  }

  // 🔴 ONLY FIX IS HERE (NO LOGIC REMOVED)
  afterPaymentSuccess(response: any) {

    this.http.post(
      `http://localhost:8084/order/api/after-payment/${this.user.cid}`,
      null,
      {
        params: {
          razorpayOrderId: response.razorpay_order_id,
          razorpayPaymentId: response.razorpay_payment_id
        }
      }
    ).subscribe({

      // ✅ success
      next: () => {
        alert('Order placed successfully!');
        this.cartService.clearCart(this.user.cid).subscribe((data:any)=>{
          console.log("cart items deleted successfully");
        });
        
        this.router.navigate(['/account/orders']);
      },

      // ✅ even if backend returns error AFTER saving order
      error: (err) => {
        console.error(err);
        alert('Payment failed');
        this.router.navigate(['/account/orders']);
      }

    });
  }
}
