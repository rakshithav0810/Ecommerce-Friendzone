import { Component, OnInit } from '@angular/core';
import { Product } from '../../../models/product';
import { ProductserviceService } from '../../services/productservice.service';
import { ActivatedRoute, Router } from '@angular/router'; 
import { CommonModule } from '@angular/common'; // ⬅️ NEW: Import CommonModule
import { RouterModule } from '@angular/router'; // Ensure RouterModule is also here for router-related features

@Component({
  selector: 'app-customer-product-grid',
  standalone: true, // This component is standalone
  templateUrl: './customer-product-grid.component.html',
  styleUrls: ['./customer-product-grid.component.css'],
  imports: [
    CommonModule,     // ⬅️ CRITICAL FIX: Provides *ngIf, *ngFor, TitleCasePipe, NumberPipe, etc.
    RouterModule      // Provides router-related features if used
  ]
})
export class CustomerProductGridComponent implements OnInit {
  
  products: Product[] = []; 
  allProducts: Product[] = []; 
  currentCategoryName: string = ''; 

  constructor(
    private productService: ProductserviceService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // ... logic remains the same
    this.productService.getAllProducts().subscribe(data => {
      this.allProducts = data;
      this.route.paramMap.subscribe(params => {
        this.currentCategoryName = params.get('categoryName') || 'all'; 
        this.filterProducts();
      });
    });
  }
  
  filterProducts(): void {
    const category = this.currentCategoryName.toLowerCase();
    
    if (category === 'all') {
      this.products = this.allProducts;
      return;
    }
    
    this.products = this.allProducts.filter(p => 
      p.category?.categoryName?.toLowerCase() === category 
    );
  }

  addToCart(product: Product): void {
    console.log(`Added ${product.pname} to cart!`);
    alert(`${product.pname} added to cart!`);
  }

  buyNow(product: Product): void {
    console.log(`Initiating Buy Now for ${product.pname}`);
    alert(`Redirecting to checkout for ${product.pname}`);
  }
}