import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  standalone:false,
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent {

  email: string = "";
  newPassword: string = "";

  constructor(private userService: UserService, private router: Router) {}

  resetPassword() {
    if (!this.email || !this.newPassword) {
      alert("Please fill all fields");
      return;
    }
    console.log('EMAIL SENT TO BACKEND:', this.email.trim());
    this.userService.updatePasswordByEmail(this.email, this.newPassword)
  .subscribe({
    next: () => {
      alert("Password updated successfully!");
      this.router.navigate(['/login']);
    },
    error: (err) => {
      if (err.status === 404) {
        alert("No user found with this email");
      } else {
        alert("Password updated, but server response failed");
      }
    }
  });
}
}
