import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-address',
  standalone:false,
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit {
  address: any = null;

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    const user = this.userService.getLoggedInUser();
    if (!user) return;

    this.address = user.address; // because backend returns string, not object
  }
}
