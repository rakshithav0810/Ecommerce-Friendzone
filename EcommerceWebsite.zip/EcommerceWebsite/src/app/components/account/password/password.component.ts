import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../../services/user.service';

@Component({
  selector: 'app-password',
  standalone:false,
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent {
  passwordForm: FormGroup;
  message: string = '';

  constructor(private fb: FormBuilder, private userService: UserService) {
    this.passwordForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  updatePassword() {
    if (this.passwordForm.invalid) return;

    const newPassword = this.passwordForm.value.newPassword;

    this.userService.updatePassword(newPassword).subscribe({
      next: updatedUser => {
        this.message = 'Password updated successfully!';
        this.userService.saveUser(updatedUser);
      },
      error: err => {
        console.error('updatePassword error', err);
        this.message = 'Failed to update password';
      }
    });
  }
}
