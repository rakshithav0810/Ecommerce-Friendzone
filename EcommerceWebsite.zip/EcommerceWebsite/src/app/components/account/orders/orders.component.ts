import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { UserService } from '../../../services/user.service';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-orders',
  standalone: false,
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.css']
})
export class OrdersComponent implements OnInit {

  orders: any[] = [];

  constructor(
    private userService: UserService,
    private http: HttpClient,
    private cd:ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const user = this.userService.getLoggedInUser();
    if (!user) return;

    // ✅ SAME API — UNCHANGED
    this.http
      .get<any[]>(`http://localhost:8084/order/api/customer/${user.cid}`)
      .subscribe({
        next: data => {
          this.orders=data;
          this.cd.detectChanges();
        },
        error: err => {
          console.error('Failed to load orders', err);
        }
      });
  }
}
