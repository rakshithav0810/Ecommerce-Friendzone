import { Component } from '@angular/core';

@Component({
  selector: 'app-feedback',
  standalone: false,
  templateUrl: './feedback.component.html',
  styleUrl: './feedback.component.css'
})
export class FeedbackComponent {
  submitted = false;

  questions = [
    "How satisfied are you with our clothing quality?",
    "How satisfied are you with the pricing?",
    "How likely are you to recommend us to others?",
    "How satisfied are you with our customer service?",
    "How satisfied are you with the delivery experience?"
  ];

  // Default rating = 0 for each question
  feedback: number[] = new Array(this.questions.length).fill(0);

  rate(questionIndex: number, star: number) {
    this.feedback[questionIndex] = star;
  }

  submitFeedback() {
    this.submitted = true;
    console.log("Customer Feedback:", this.feedback);
  }
}

