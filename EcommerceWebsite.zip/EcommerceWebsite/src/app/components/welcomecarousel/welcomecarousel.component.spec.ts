import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WelcomecarouselComponent } from './welcomecarousel.component';

describe('WelcomecarouselComponent', () => {
  let component: WelcomecarouselComponent;
  let fixture: ComponentFixture<WelcomecarouselComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [WelcomecarouselComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WelcomecarouselComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
