import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

interface CategorySlide {
  name: string;
  imageSrc: string;
  description: string;
  routeLink: string;
}
@Component({
  selector: 'app-welcomecarousel',
  standalone: false,
  templateUrl: './welcomecarousel.component.html',
  styleUrl: './welcomecarousel.component.css'
})
export class WelcomecarouselComponent implements OnInit
{
storeName: string = 'FRIEND ZONE';
  tagline: string = 'Clothing Store';
  //Inject Router for navigation if links are Angular routes
  constructor(private router: Router ){ }

  ngOnInit(): void {
    // Initialization logic, possibly fetching welcome message or featured data
  }
  
  // Navigation function for the carousel buttons
 
  goToCategory(route:string):void{
    this.router.navigate([route]);
  }
  
  // Array of category data for the carousel
  categorySlides: CategorySlide[] = [
    {
      name: 'Women',
      imageSrc: 'assets/images/women carousel.PNG', // Replace with your image paths
      description: 'Find the latest trends and styles just for you.',
      routeLink: '/products/women' 
    },
    {
      name: 'Men',
      imageSrc: 'assets/images/men carousel.jpg', // Replace with your image paths
      description: 'Durable and stylish clothing for every occasion.',
      routeLink: '/products/men'
    },
    {
      name: 'Kids',
      imageSrc: 'assets/images/kids carousel.png', // Replace with your image paths
      description: 'Fun, comfortable, and durable clothing for your little ones.',
      routeLink: '/products/kids'
    }
  ]; 
  
}


