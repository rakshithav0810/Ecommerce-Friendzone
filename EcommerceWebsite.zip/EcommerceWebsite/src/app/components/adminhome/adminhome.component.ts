import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-adminhome',
  standalone: false,
  templateUrl: './adminhome.component.html',
  styleUrl: './adminhome.component.css'
})
export class AdminhomeComponent implements OnInit{
  userName: string = '';

  constructor(private customerService: UserService) {}

  ngOnInit(): void {
    const email = localStorage.getItem("loggedEmail");
    console.log("EMAIL FROM LOCAL STORAGE =", email);

    if (email) {
      this.customerService.getCustomerByEmail(email)
        .subscribe((data: any) => {
          this.userName = data.userName;  
        });

    }
  }

}
