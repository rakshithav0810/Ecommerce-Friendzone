import { Component } from '@angular/core';
import { UserService } from '../../services/user.service';
import { Customer } from '../../../models/Customer';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.css',
  
})
export class RegisterComponent {
  errorMessage: any = {};
  constructor(private userService:UserService) {}
  customer=new Customer();

  registerUser()
  {
    this.errorMessage = {}; 
    this.userService.registerUser(this.customer).subscribe(
      (userObj:any)=>
      {
        if(userObj!=null)
        {
          alert("user registration is successfull")
        }
      },(error) => {
      if (error.status === 400 && error.error) {
        this.errorMessage = error.error;  
        console.log(error);
      } else {
        alert("Something went wrong!");
      }
      }
    );
      
  }


}