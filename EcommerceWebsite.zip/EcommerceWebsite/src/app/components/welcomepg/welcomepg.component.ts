import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcomepg',
  standalone: false,
  templateUrl: './welcomepg.component.html',
  styleUrl: './welcomepg.component.css'
})
export class WelcomepgComponent implements OnInit {

  ngOnInit(): void {
    
  }

}
