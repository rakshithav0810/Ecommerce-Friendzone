import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerdetComponent } from './customerdet.component';

describe('CustomerdetComponent', () => {
  let component: CustomerdetComponent;
  let fixture: ComponentFixture<CustomerdetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomerdetComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CustomerdetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
