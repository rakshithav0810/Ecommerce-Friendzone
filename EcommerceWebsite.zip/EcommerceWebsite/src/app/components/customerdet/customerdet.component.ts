import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Customer } from '../../../models/Customer';
import { CustomerService } from '../../services/customerservice.service';

@Component({
  selector: 'app-customerdet',
  standalone: false,
  templateUrl: './customerdet.component.html',
  styleUrl: './customerdet.component.css'
})
export class CustomerdetComponent implements OnInit{
  customers: Customer[] = [];
  loading: boolean = false;
p: number = 1;
count: number = 5;
  selectedCustomer: Customer | null = null;

 

  constructor(private customerService: CustomerService, private cdr : ChangeDetectorRef) {}

  ngOnInit(): void {
    this.loadCustomers();
  }

  loadCustomers() {
    this.customerService.getAllCustomers().subscribe(data => {
      this.customers = data;
    });
  }

  editCustomer(customer: Customer) {
  this.selectedCustomer = { ...customer };
}

  updateCustomer(c: Customer) {
  this.customerService.updateCustomerByCustId(c.cid!, c)
    .subscribe(() => this.loadCustomers());
  }



  deleteCustomer(cid: number) {
    if (!confirm("Delete this customer?")) return;
    this.customers = this.customers.filter(c => c.cid !== cid);
    this.customerService.deleteCustById(cid).subscribe({
      next: () => {
        this.loadCustomers();
        setTimeout(() => {
          this.cdr.detectChanges();
        }, 0);
      },
      error: err => {
        console.error(err);
        this.loadCustomers();
      }
    });
  }

  saveUpdate() {
  if (!this.selectedCustomer) return;

  this.customerService
    .updateCustomerByCustId(this.selectedCustomer.cid!, this.selectedCustomer)
    .subscribe(() => {
      this.loadCustomers();
      this.selectedCustomer = null;
    });
  }
}


