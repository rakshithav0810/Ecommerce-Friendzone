import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Product } from '../../../models/product';
import { ProductCategory } from '../../../models/product-category';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ProductserviceService } from '../../services/productservice.service';
import { CategoryserviceService } from '../../services/categoryservice.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';   // ✅ ADDED

@Component({
  selector: 'app-products',
  standalone: false,
  templateUrl: './products.component.html',
  styleUrl: './products.component.css'
})
export class ProductsComponent implements OnInit {

  p: number = 1; 
  count: number = 3;
  
  products: Product[] = [];
  categories: ProductCategory[] = [];

  productForm!: FormGroup;

  editMode = false;
  editId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private productService: ProductserviceService,
    private categoryService: CategoryserviceService,
    private http: HttpClient,
    private cd: ChangeDetectorRef,
    private route: ActivatedRoute            // ✅ ADDED
  ) {}

  ngOnInit(): void {
    this.productForm = this.fb.group({
      pname: [''],
      brand: [''],
      unitPrice: [''],
      unitsInStock: [''],
      imageUrl: [''],
      categoryId: ['']
    });

    // ✅ Get category from the URL: women, men, kids
    const categoryParam = this.route.snapshot.paramMap.get('category');
    console.log("Category received from URL:", categoryParam);

    if (categoryParam) {
      // CUSTOMER VIEW — filter by women/men/kids
      this.loadProductsByCategory(categoryParam);
    } else {
      // ADMIN VIEW — load all products
      this.loadProducts();
    }

    this.loadCategories();
  }

  // ✅ NEW FUNCTION — Loads products filtered by URL category
  loadProductsByCategory(category: string) {
    this.productService.getAllProducts().subscribe(res => {
      this.products = res.filter(
        p => p.category?.categoryName?.toLowerCase() === category.toLowerCase()
      );
    });
  }

  loadProducts() {
    this.productService.getAllProducts().subscribe(res => this.products = res);
  }

  loadCategories() {
    this.http.get<ProductCategory[]>('http://localhost:8084/productCategory/api')
      .subscribe(data => {
        this.categories = data;
      });
  }

  onSubmit() {
    console.log("hello");
    const data = {
      ...this.productForm.value,
      category: { id: this.productForm.value.categoryId }
    };

    if (!this.editMode) {
      this.productService.saveProduct(data).subscribe(() => {
        this.loadProducts();
        this.productForm.reset();
      });
    } else {
      this.productService.updateProductById(this.editId!, data).subscribe(() => {
        this.loadProducts();
        this.resetForm();
      });
    }
  }

  editProduct(p: Product) {
    this.editMode = true;
    this.editId = p.pid;

    this.productForm.patchValue({
      pname: p.pname,
      brand: p.brand,
      unitPrice: p.unitPrice,
      unitsInStock: p.unitsInStock,
      imageUrl: p.imageUrl,
      categoryId: p.category.id
    });
  }

  resetForm() {
    this.editMode = false;
    this.editId = null;
    this.cd.detectChanges();
    this.productForm.reset();
  }

  deleteProduct(id: number) {
    if (!confirm("Delete this product?")) return;
  
    this.products = this.products.filter(p => p.pid !== id);
  
    this.productService.deleteProductByProductId(id).subscribe({
      next: () => {
        this.loadProducts();
        setTimeout(() => {
          this.cd.detectChanges();
        }, 0);
      },
      error: err => {
        console.error(err);
        this.loadProducts();
      }
    });
  }

  getCategoryName(categoryId: number | null): string {
    if (categoryId === null || categoryId === undefined) {
      return 'N/A';
    }
    const foundCategory = this.categories.find(c => c.id === categoryId);
    return foundCategory ? foundCategory.categoryName : 'Unknown Category';
  }

}
