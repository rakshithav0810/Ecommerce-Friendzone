export interface Product {
  pid: number;
  pname: string;
  brand: string;
  unitPrice: number;
  unitsInStock: number;
  imageUrl: string;
  description:string;
  category: {
    id: number;
    categoryName: string;
  };
}